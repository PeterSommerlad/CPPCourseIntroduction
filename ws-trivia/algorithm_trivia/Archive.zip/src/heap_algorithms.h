#ifndef HEAP_ALGORITHMS_H_
#define HEAP_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_heap_algorithms();

#endif /* HEAP_ALGORITHMS_H_ */
