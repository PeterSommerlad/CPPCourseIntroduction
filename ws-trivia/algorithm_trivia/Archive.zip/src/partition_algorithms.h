#ifndef PARTITION_ALGORITHMS_H_
#define PARTITION_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_partition_algorithms();

#endif /* PARTITION_ALGORITHMS_H_ */
