#ifndef FILL_AND_GENERATE_ALGORITHMS_H_
#define FILL_AND_GENERATE_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_fill_and_generate_algorithms();

#endif /* FILL_AND_GENERATE_ALGORITHMS_H_ */
