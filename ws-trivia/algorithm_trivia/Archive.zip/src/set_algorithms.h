#ifndef SET_ALGORITHMS_H_
#define SET_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_set_algorithms();

#endif /* SET_ALGORITHMS_H_ */
