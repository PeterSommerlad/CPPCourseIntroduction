#ifndef MIN_MAX_ALGORITHMS_H_
#define MIN_MAX_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_min_max_algorithms();

#endif /* MIN_MAX_ALGORITHMS_H_ */
