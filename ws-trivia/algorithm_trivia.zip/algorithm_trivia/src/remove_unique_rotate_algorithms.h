#ifndef REMOVE_UNIQUE_ROTATE_ALGORITHMS_H_
#define REMOVE_UNIQUE_ROTATE_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_remove_unique_rotate_algorithms();

#endif /* REMOVE_UNIQUE_ROTATE_ALGORITHMS_H_ */
