#ifndef NUMERIC_ALGORITHMS_H_
#define NUMERIC_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_numeric_algorithms();

#endif /* NUMERIC_ALGORITHMS_H_ */
