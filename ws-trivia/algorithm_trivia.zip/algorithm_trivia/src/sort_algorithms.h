#ifndef SORT_ALGORITHMS_H_
#define SORT_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_sort_algorithms();

#endif /* SORT_ALGORITHMS_H_ */
