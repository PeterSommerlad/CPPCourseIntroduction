#include "sayhello.h"
#include <ostream>
void sayhello(std::ostream &out) {
	out << "!!!Hello World!!!\n";
}