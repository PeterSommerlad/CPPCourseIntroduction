#ifndef FIND_ALGORITHMS_H_
#define FIND_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_find_algorithms();

#endif /* FIND_ALGORITHMS_H_ */
