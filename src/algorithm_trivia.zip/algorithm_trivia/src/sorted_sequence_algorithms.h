#ifndef SORTED_SEQUENCE_ALGORITHMS_H_
#define SORTED_SEQUENCE_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_sorted_sequence_algorithms();

#endif /* SORTED_SEQUENCE_ALGORITHMS_H_ */
