#ifndef PROPERTY_CHECKING_ALGORITHMS_H_
#define PROPERTY_CHECKING_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_property_checking_algorithms();

#endif /* PROPERTY_CHECKING_ALGORITHMS_H_ */
