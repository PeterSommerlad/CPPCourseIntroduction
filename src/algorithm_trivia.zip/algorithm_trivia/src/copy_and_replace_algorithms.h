#ifndef COPY_AND_REPLACE_ALGORITHMS_H_
#define COPY_AND_REPLACE_ALGORITHMS_H_

#include "cute_suite.h"

extern cute::suite make_suite_copy_and_replace_algorithms();

#endif /* COPY_AND_REPLACE_ALGORITHMS_H_ */
