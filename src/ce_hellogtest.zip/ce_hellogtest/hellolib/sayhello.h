#ifndef SAYHELLO_H_
#define SAYHELLO_H_
#include <iosfwd>
void sayhello(std::ostream &out);
#endif /* SAYHELLO_H_ */
